#ifndef COMPRESS_H_
#define COMPRESS_H_



void compress(char*, char*);
void compress_recursive(char*, char*);

#endif /* COMPRESS_H_ */
