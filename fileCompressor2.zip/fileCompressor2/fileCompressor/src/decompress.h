

#ifndef DECOMPRESS_H_
#define DECOMPRESS_H_

void decompress(char*, char*);
void decompress_recursive(char*, char*);

#endif /* DECOMPRESS_H_ */
